puts "TRICK #{
  ((File.mtime("authors.markdown") - File.mtime(__FILE__)) *
   (File.mtime("remarks.markdown") - File.mtime(__FILE__)))
   .to_i.to_s(30).upcase
}!"
